# Security Policy

## Supported Versions

Only the current version is supported (why would there be others)
Also the version archived on old domain will accept vulnerabilities

| Version         | Supported          |
| --------------- | ------------------ |
| Current Version | :white_check_mark: |
| Old Versions    | :x:                |

## Reporting a Vulnerability

If there is a security vulnerability active on the site, you can PM
me on one of my links (twitter, insta, github)

I will try to update you when it is done, but while I am fixing it,
you must not tell anyone about the issue. Thanks
