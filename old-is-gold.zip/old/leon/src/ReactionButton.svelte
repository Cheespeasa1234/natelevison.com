<script>
	export let count, emoji;
</script>
<button on:click>
	{emoji} - {count}
</button>