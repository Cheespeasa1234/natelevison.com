# Cheespeasa's website
This is the website repository for Cheespeasa's website.

### Resources

- Cool links css: Abdelrhman Said
- Some help: Thomas Rottinger @ https://github.com/CasualQuasar
- Literally all of the code: google.com

### My Tech Stack

Frontend:
HTML, JS, and CSS

Backend:
Node.js, Java

IDE:
VSCode (Dark Mode!!)
