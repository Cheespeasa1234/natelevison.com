How to use this download:

1. Make sure to read the LICENSE in this directory
2. Drag and drop the .java file into the src folder in eclipse
3. You now have access to the file!

How to use Array class:

1. You can read the documentation in the .java file itself for information about methods and other stuff.
2. Choose the class you want to list, for example, String.
3. Make a new Array, like so: "Array<String> array = new Array<String>();", pretty much how you would use ArrayList. 
4. Then you can use it however you want!

Make sure to check back on my website so that you can download new versions.